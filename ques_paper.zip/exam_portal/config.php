<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	// Create connection
	mysql_connect("localhost","root","");
	mysql_select_db("online");
    ?>