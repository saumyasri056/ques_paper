<?php
 include 'config.php';

$ans1=$_POST['q2'];
$query="UPDATE answers SET ans1='$ans1'";
     //echo $query;

     //$query="UPDATE `answers` SET `ans1`=[$ans1] WHERE 1
    //$query="INSERT INTO `online`.`answers` (`ans1`) VALUES ('$ans1')";
    $run=mysql_query($query);
    
      header('location:ques2.html');
      ?>