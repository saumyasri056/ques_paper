<?php
 include 'config.php';

$ans2=$_POST['q1'];
     
    $query="UPDATE answers2 SET ans2='$ans2'";
    $run=mysql_query($query);
     
      header('location:ques3.html');
      ?>