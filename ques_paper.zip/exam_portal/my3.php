<?php

include('config.php');

$ans3=$_POST['q3'];
 
    $query="UPDATE answers3 SET ans3='$ans3'";
    $run=mysql_query($query);
     
      header('location:ques4.html');

?>	