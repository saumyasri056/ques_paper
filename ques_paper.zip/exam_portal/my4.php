<?php


include('config.php');

$ans4=$_POST['q4'];

$query="UPDATE answers4 SET ans4='$ans4'";
    $run=mysql_query($query);
     
header("location: score.php");

?>