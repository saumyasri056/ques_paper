<!DOCTYPE HTML> 
  <html lang="en">
  <head>
     <link rel="stylesheet"href="style.css">
    <title>result</title>
  </head>
<body>
<h1> u have successfully submitted ur answers</h1>
<p> to view ur result click on result.</p>
<div class="absolute2">
<span id="countdown" class="timer"></span>
<script>
var seconds = 60;
function secondPassed() {
    var minutes = Math.round((seconds - 30)/60);
    var remainingSeconds = seconds % 60;
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds;  
    }
    document.getElementById('countdown').innerHTML = minutes + ":" + remainingSeconds;
    if (seconds == 0) {
        clearInterval(countdownTimer);
        document.getElementById('countdown').innerHTML = "Buzz Buzz";
    } else {
        seconds--;
    }
}
 
var countdownTimer = setInterval('secondPassed()', 1000);
</script>
</div>

	
	
</body>

</html>