<?php
session_start();

include('config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
   <link rel="stylesheet"href="scorestyle.css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>



    <title> result </title>
<style>

</style>
</head>
<div class="div2">
 Result!
<body class="body">
 </div>
<div class="div1">
</div>
<div class="right">
  
<p class="p1">
    Question 1:
    Which of the following languages is more suited to a structured program?
    <br>
</p>
<p class="para">
<?php
$query="select * from `answers`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    echo "marked ans is:";
    echo $data['ans1'] ;
    echo "<br>";
    echo "correct ans is:1";
    ?>
    </p>
    </div> 
    <hr>
    <div class="right">
  
<p class="p1">
    Question 2:
    The tracks on a disk which can be accessed without repositioning the R/W heads is:
    <br>
</p>
<p class="para">
<?php
$query="select * from `answers2`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    echo "marked ans is:";
    echo $data['ans2'] ;
    echo "<br>";
    echo "correct ans is:Surface";
       
       
     ?>
    </p>
    </div> 
<hr>
<div class="right">
  
<p class="p1">
    Question 3:
    Which part interprets program instructions and initiate control operations?
    <br>
</p>
<p class="para">
<?php
$query="select * from `answers3`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    echo "marked ans is:";
    echo $data['ans3'] ;
    echo "<br>";
    echo "correct ans is:Input";
       ?>
    </p>
    </div> 
<hr>
 <div class="right">
  
<p class="p1">
    Question 4:
    Which of the following is the 1's complement of 10? 
     <br>
</p>
<p class="para">
<?php
$query="select * from `answers4`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    echo "marked ans is:";
    echo $data['ans4'] ;
    echo "<br>";
    echo "correct ans is:01";
       ?>
    </p>
    </div> 
<hr>
<?php
$score=0;
$query="select * from `answers`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    if($data['ans1']=='FORTAN')
    {
     $score=$score+1;
    }
    else
    {
     $score=$score+0;
    }
    //echo $score;

    $query="select * from `answers2`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    if($data['ans2']=='Surface')
    {
     $score=$score+1;
    }
    else
    {
     $score=$score+0;
    }
    //echo $score;

$query="select * from `answers3`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    if($data['ans3']=='Input')
    {
     $score=$score+1;
    }
    else
    {
     $score=$score+0;
    }
    //echo $score;
    $query="select * from `answers4`";
     $run=mysql_query($query);
    $data=mysql_fetch_assoc($run);
    if($data['ans4']=='01')
    {
     $score=$score+1;
    }
    else
    {
     $score=$score+0;
    }

    ?>
    <div class="div2">
 score  <?php echo $score;?>/10
</div>
</body>
</HTML>